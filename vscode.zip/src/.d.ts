declare module 'crypto-js'
